#include <stdio.h>
#include <stdlib.h>
#include <mem.h>
int main()
{
    int *p =(int *) malloc(sizeof(int));
    // scanf("%d",p);
    // *p = 10;
    memset(p,1,4);
    printf("valP - %d\n",*p);

    int *q =(int *) calloc(1,sizeof(int));
    // scanf("%d",q);
    *q = 20;
    printf("valQ - %d\n",*q);

    int *pArr =(int *) malloc(3*sizeof(int));
    // scanf("%d",p);
    *pArr = 100;
    *(pArr+1) = 101;
    *(pArr+2) = 102;
    *(pArr+3) = 103;
    printf("valPArr0 - %d with add as %d\n",*pArr,pArr);
    printf("valPArr1 - %d\n",*pArr+1);
    printf("valPArr2 - %d\n",*pArr+2);
    printf("valPArr3 - %d  with size of array as %d\n",*(pArr+3),sizeof(pArr));

    pArr =(int *) realloc(pArr,500*sizeof(int));
    printf("valPArr0 - %d with add as %d\n",*pArr,pArr);

    free(pArr);
    free(q);
    free(p);
    // printf("valPArr2 - %d\n",*(pArr+2));
 
 
    int **qArr =(int **) malloc(3*sizeof(int *));
    if(qArr != NULL)
        printf("Success\n");

    qArr[0] = (int *) malloc(5*sizeof(int));
    if(qArr[0] != NULL)
        printf("Success\n");
    qArr[1] = (int *) malloc(5*sizeof(int));
    if(qArr[1] != NULL)
        printf("Success\n");
    qArr[2] = (int *) malloc(5*sizeof(int));
    if(qArr[2] != NULL)
        printf("Success\n");
    int cnt = 1001;
    for(int i = 0 ; i<3 ; i++)
    {
        for(int j = 0 ; j<5 ; j++)
            qArr[i][j] = cnt++;
    }
    for(int i = 0 ; i<3 ; i++)
    {
        for(int j = 0 ; j<5 ; j++)
            printf("[%d][%d] = %d \t %d\n",i,j,qArr[i][j],&qArr[i][j]);
    }
    // *qArr[0];
    // *qArr[0];
 
    return 0;
}