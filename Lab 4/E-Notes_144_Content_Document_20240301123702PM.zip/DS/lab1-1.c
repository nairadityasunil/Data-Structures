#include <stdio.h>
struct student
{
    char name[50];
    int id;
    int marks;
};
void collect(struct student *,int);
void display(struct student *,int);
void filter(struct student *,int, int);
int main(int argc, char *argv[])
{
    int N = atoi(argv[1]);
    int M = atoi(argv[2]);
    // printf("%d %d",N,M);
    struct student s[N];
    struct student *p = s;

    //Collect
    collect(p,N);    
    //Display all
    display(p,N); 
    //Filter
    filter(p,N,M);

    return 0;
}
void collect(struct student *stu,int sz)
{
    for(int i = 0; i<sz;i++)
    {  
        printf("Enter Name: "); 
        scanf("%s",stu->name);
        printf("Enter ID: "); 
        scanf("%d",&stu->id);
        printf("Enter Marks: "); 
        scanf("%d",&stu->marks);
        printf("----\n"); 
        stu++;
    }
}
void display(struct student *stu,int sz)
{
    for(int i = 0; i<sz;i++)
    {  
        printf("Name: "); 
        printf("%s\t",stu->name);
        printf("ID: "); 
        printf("%d\t",stu->id);
        printf("Marks: "); 
        printf("%d\t",stu->marks);
        printf("----\n"); 
        stu++;
    }
        printf("\n--------------------------------\n"); 
}
void filter(struct student *stu,int sz, int thres)
{
    for(int i = 0; i<sz;i++)
    { 
        if(stu->marks > thres)
            display(stu,1);
        stu++; 
    }
}
