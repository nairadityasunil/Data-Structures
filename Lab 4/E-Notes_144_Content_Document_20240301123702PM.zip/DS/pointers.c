#include <stdio.h>
#include <stdlib.h>
void add(int a,int b)
{
    // return a+b;
    printf("%d\n",a+b);
}
void sub(int a,int b)
{
    // return a+b;
    printf("%d\n",a-b);
}
int main()
{
    // printf("%d\n",add(5,5));
    void add(int,int);
    add(15,5);
    void (*p[2]) (int,int);
    p[0] = add;
    p[1] = sub;
    p[0](15,5);
    p[1](15,5);

    // int a[5][5]={1,2,3,4,5,6,7,8,9,10};
    // int aa[15]={1,2,3,4,5};
    // int bb[5]={1,2,3,4,5};
    // int cc[10]={1,2,3,4,5};
    // int *p[5];
    // p[0] = a[0][3];
    // p[1] = a[1];
    // p[2] = a[2];
    // p[3] = a[3];
    // p[4] = a[4];
    // for(int i =0; i<5;i++)
    // {
    //     for(int j =0; j<5;j++)
    //         // printf("%d - ",*p++);
    //     printf("\n");
    // }
    // p[0] = aa;
    // p[2] = cc;
    // p[1] = bb;

    // int a = 3000;
    // int *p = (&a+2);//22334567667
    // // int *q = (int *)100;
    // *p = 1000;
    // printf("%d - %d\n",*p,a);
    // printf("%d - %d\n",p,&a);


    // int a[] = {10,20,30};
    // int b[] = {40,50,60};
    // printf("A - %d - %d - %d\n",a[0],a[1],a[2]);
    // printf("B - %d - %d - %d\n",*a,*(a+1),*(a+2));
    // int *p = a;
    // printf("P - %d - %d - %d\n",*p,*(p+1),*(p+2));
    // printf("ADD - %d - %d - %d - %d\n",&a,&b,&p,p);
    // int *q = (int *)malloc(3*sizeof(int));
    // *q = 70;
    // *(q+1) = 80;
    // q[2] = 90;
    // printf("Q - %d - %d - %d\n",*q,*(q+1),*(q+2));
    // printf("ADD - %d - %d \n",q,&q);
    return 0;
}