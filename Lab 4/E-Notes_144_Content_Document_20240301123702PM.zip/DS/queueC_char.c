#include <stdio.h>
#include <stdlib.h>

typedef struct {
    // char charStackArr[MAX];
    char *items;
    int size;
    int front;
    int rear;
}CharQueue;

CharQueue* CreateCharQueue(int max)
{
    CharQueue *q = (CharQueue *) calloc(1,sizeof(CharQueue));
    q->front = q->rear = -1;
    q->size = max;
    q->items = (char *)calloc(q->size,sizeof(char));
    return q;
}
void EnqueueFront_CharQueue(CharQueue *q, char ch)
{
    //Overflow
    if(((q->rear+1)%q->size) == q->front)
    {
        printf("Queue is FULL - Enqueue Operation Failed\n");
        return;
    }
    if(q->front == 0)
    {
        q->front = q->size-1;
    }
    else if(q->front == -1)
    {
        q->front = q->rear = 0;
    }
    else
    {
        q->front--;
    }
    q->items[q->front] = ch;
}

void Enqueue_CharQueue(CharQueue *q, char ch)//Rear
{
    //Overflow
    if(((q->rear+1)%q->size) == q->front)
    {
        printf("Queue is FULL - Enqueue Operation Failed\n");
        return;
    }
    q->rear = (q->rear + 1)%q->size;
    q->items[q->rear] = ch;
    //If first update first
    if(q->front == -1)
        q->front++;
}

void DequeueRear_CharQueue(CharQueue *q)
{
    if(q->front == -1 || (q->rear == -1))
    {
        printf("Queue is Empty - Dequeue Operation Failed\n");
        return;
    }
    printf("DequeueRear Operation: %c\n",q->items[q->rear]);
    if(q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->rear--;
    if(q->rear < 0) q->rear = q->size-1;
}
void Dequeue_CharQueue(CharQueue *q)//Front
{
    if(q->front == -1 || (q->rear == -1))
    {
        printf("Queue is Empty - Dequeue Operation Failed\n");
        return;
    }
    printf("Dequeue Operation: %c\n",q->items[q->front]);
    if(q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->front = (q->front + 1)%q->size;

}

void Display_CharQueue(CharQueue q)
{
    if(q.front == -1 || (q.rear == -1))
    {
        printf("Queue is Empty - Display Operation Failed\n");
        return;
    }
    printf(" |=| F |=|\t ");
    if(q.front<=q.rear)
    {
        for(int i=q.front;i<=q.rear;i++)
        {
            printf(" %c -",q.items[i]);
        }
    }
    else
    {
        for(int i=q.front;i<q.size;i++)
        {
            printf(" %c -",q.items[i]);
        }
        for(int i=0;i<=q.rear;i++)
        {
            printf(" %c -",q.items[i]);
        }
    }
    // for(int i=q.front;i<=q.rear;i = (i+1)%q.size)
    // {
    //     printf(" %c -",q.items[i]);
    // }
    printf("\t |=| R |=| \n");
}

void DestroyCharQueue(CharQueue *q)
{
    free(q->items);
    free(q);
    q = NULL;
}