#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char *items;
    int size;
    int front;
    int rear;
}CharDQueue;

CharDQueue* CreateCharDQueue(int max)
{
    CharDQueue *q = (CharDQueue *) calloc(1,sizeof(CharDQueue));
    q->front = q->rear = -1;
    q->size = max;
    q->items = (char *)calloc(q->size,sizeof(char));
    return q;
}

void EnqueueRear_CharDQueue(CharDQueue *q, char ch)
{
    //Overflow
    if(q->rear >= q->size-1)
    {
        printf("Queue is FULL - Enqueue Operation Failed\n");
        return;
    }
    q->rear++;
    q->items[q->rear] = ch;
    //If first update first
    if(q->front == -1)
        q->front++;
}

void DequeueFront_CharDQueue(CharDQueue *q)
{
    if(q->front == -1 || (q->front>q->rear))
    {
        printf("Queue is Empty - Dequeue Operation Failed\n");
        return;
    }
    printf("Dequeue Operation: %c\n",q->items[q->front]);
    if(q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->front++;
}

void EnqueueFront_CharDQueue(CharDQueue *q,char ch)
{
    if(q->front == 0)
    {
        printf("Queue is FULL - Enqueue at Front Failed\n");
        return;
    }
    if(q->front == -1)
        q->front = q->rear = 0;
    else
        q->front--;
    q->items[q->front] = ch;
}

void DequeueRear_CharDQueue(CharDQueue *q)
{
    if(q->rear == -1)
    {
        printf("Queue is Empty - Dequeue at Rear Failed\n");
        return;
    }
    printf("Dequeue at Rear Operation: %c\n",q->items[q->rear]);
    if(q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->rear--;

}

void Display_CharDQueue(CharDQueue q)
{
    if(q.front == -1 || (q.front>q.rear))
    {
        printf("Queue is Empty - Display Operation Failed\n");
        return;
    }
    printf(" = F = ");
    for(int i=q.front;i<=q.rear;i++)
    {
        printf(" %c -",q.items[i]);
    }
    printf(" = R = \n");
}

void DestroyCharDQueue(CharDQueue *q)
{
    free(q->items);
    free(q);
    q = NULL;
}