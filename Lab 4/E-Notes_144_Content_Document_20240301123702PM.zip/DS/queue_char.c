#include <stdio.h>
#include <stdlib.h>

// // #define MAX 50

typedef struct {
    // char charStackArr[MAX];
    char *items;
    int size;
    int front;
    int rear;
}CharQueue;

CharQueue* CreateCharQueue(int max)
{
    CharQueue *q = (CharQueue *) calloc(1,sizeof(CharQueue));
    q->front = q->rear = -1;
    q->size = max;
    q->items = (char *)calloc(q->size,sizeof(char));
    return q;
}

// int Is_CharStackEmpty(CharStack S)
// {
//     if(S.top < 0)  // top == -1
//         return 1;
//     return 0;
// }

// int Is_CharStackFull(CharStack S)
// {
//     if(S.top >= S.max-1)  // top == MAX
//         return 1;
//     return 0;
// }

void Enqueue_CharQueue(CharQueue *q, char ch)
{
    //Overflow
    if(q->rear >= q->size-1)
    {
        printf("Queue is FULL - Enqueue Operation Failed\n");
        return;
    }
    q->rear++;
    q->items[q->rear] = ch;
    //If first update first
    if(q->front == -1)
        q->front++;
}

// void Push_CharStack(CharStack *S, char ch)
// {
//     if(Is_CharStackFull(*S)){
//         printf("CHARSTACK OVERFLOW - PUSH OPERATION FAILED\n");
//         return;
//     }
//     S->top++;
//     S->charStackArr[S->top] = ch;
// }

void Dequeue_CharQueue(CharQueue *q)
{
    if(q->front == -1 || (q->front>q->rear))
    {
        printf("Queue is Empty - Dequeue Operation Failed\n");
        return;
    }
    printf("Dequeue Operation: %c\n",q->items[q->front]);
    if(q->front == q->rear)
        q->front = q->rear = -1;
    else
        q->front++;

}

// char Pop_CharStack(CharStack *S)
// {
//     if(Is_CharStackEmpty(*S)){
//         printf("CHARSTACK UNDERFLOW - POP OPERATION FAILED\n");
//         return '\0';
//     }
//     char temp = S->charStackArr[S->top];
//     S->top--;
//     return temp;
// }

// char Peak_CharStack(CharStack S)
// {
//     if(Is_CharStackEmpty(S)){
//         printf("CHARSTACK UNDERFLOW - PEAK OPERATION FAILED\n");
//         return '\0';
//     }
//     char temp = S.charStackArr[S.top];
//     return temp;
// }

void Display_CharQueue(CharQueue q)
{
    if(q.front == -1 || (q.front>q.rear))
    {
        printf("Queue is Empty - Display Operation Failed\n");
        return;
    }
    printf(" = F = ");
    for(int i=q.front;i<=q.rear;i++)
    {
        printf(" %c -",q.items[i]);
    }
    printf(" = R = \n");
}
// void Display_CharStack(CharStack S)
// {
//     if(Is_CharStackEmpty(S)){
//         printf("CHARSTACK UNDERFLOW - DISPLAY OPERATION FAILED\n");
//         return;
//     }
//     // printf("TOP = %d",S.top);
//     for(int i = S.top; i>=0 ;i--)
//     {
//         printf("| %c |\n",S.charStackArr[i]);
//         printf("|---|\n");
//     }
//     printf("|***|\n");
// }

void DestroyCharQueue(CharQueue *q)
{
    free(q->items);
    free(q);
    q = NULL;
}