#include "queueC_char.c"

int main()
{
    CharQueue *q = NULL;
    q = CreateCharQueue(5);
    printf("%d - %d - %d\n",q->front,q->rear,q->size);

    Enqueue_CharQueue(q,'H');
    Enqueue_CharQueue(q,'E');
    Enqueue_CharQueue(q,'L');
    Enqueue_CharQueue(q,'L');
    Enqueue_CharQueue(q,'O');
    // Enqueue_CharQueue(q,'O');
    // EnqueueFront_CharQueue(q,'O');
    // printf("F=%d - R=%d - S=%d\n",q->front,q->rear,q->size);

    Display_CharQueue(*q);

    DequeueRear_CharQueue(q);
    Dequeue_CharQueue(q);
    Dequeue_CharQueue(q);
    Dequeue_CharQueue(q);
    // Enqueue_CharQueue(q,'X');

    // EnqueueFront_CharQueue(q,'X');
    // EnqueueFront_CharQueue(q,'X');

    // Dequeue_CharQueue(q);
    // // Dequeue_CharQueue(q);
    // // Dequeue_CharQueue(q);
    // // Dequeue_CharQueue(q);

    Display_CharQueue(*q);
    // DequeueRear_CharQueue(q);
    DequeueRear_CharQueue(q);
    Display_CharQueue(*q);

    // Enqueue_CharQueue(q,'X');
    // // printf("%d - %d - %d\n",q->front,q->rear,q->size);

    // Display_CharQueue(*q);


    DestroyCharQueue(q);
    printf("%d - %d - %d\n",q->front,q->rear,q->size);
    return 0;
}