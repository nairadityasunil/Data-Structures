#include "queueD_char.c"

int main()
{
    CharDQueue *q = NULL;
    q = CreateCharDQueue(5);
    printf("%d - %d - %d\n",q->front,q->rear,q->size);

    EnqueueRear_CharDQueue(q,'H');
    EnqueueRear_CharDQueue(q,'E');
    EnqueueRear_CharDQueue(q,'L');
    EnqueueRear_CharDQueue(q,'L');
    EnqueueRear_CharDQueue(q,'O');
    EnqueueRear_CharDQueue(q,'O');
    printf("F=%d - R=%d - S=%d\n",q->front,q->rear,q->size);

    Display_CharDQueue(*q);

    DequeueFront_CharDQueue(q);
    DequeueFront_CharDQueue(q);
    
    EnqueueFront_CharDQueue(q,'X');
    EnqueueFront_CharDQueue(q,'Y');
    EnqueueFront_CharDQueue(q,'Z');
    DequeueRear_CharDQueue(q);
    DequeueRear_CharDQueue(q);
    // // Dequeue_CharQueue(q);

    Display_CharDQueue(*q);

    // Enqueue_CharQueue(q,'X');
    // // printf("%d - %d - %d\n",q->front,q->rear,q->size);

    // Display_CharQueue(*q);


    DestroyCharDQueue(q);
    printf("%d - %d - %d\n",q->front,q->rear,q->size);
    return 0;
}