//ORDERED ARRAY

// insert an item at the appropriate position of the
// queue so that the queue is always ordered
void enqueue(int item) {
        // Check if the queue is full
        if (n == MAX_SIZE - 1) {
                printf("%s\n", "ERROR: Queue is full");
                return;
        }

        int i = n - 1;
        while (i >= 0 && item < queue[i]) {
                queue[i + 1] = queue[i];
                i--;
        }
        queue[i + 1] = item;
        n++;
}

// remove the last element in the queue
int dequeue() {
        int item;
        // Check if the queue is empty
        if (n == 0) {
                printf("%s\n", "ERROR: Queue is empty");
                return -999999;
        }
        item = queue[n - 1];
        n = n - 1;
        return item;
}