#include <stdio.h>
#include <stdlib.h>

// #define MAX 50

typedef struct {
    // char charStackArr[MAX];
    char *charStackArr;
    int max;
    int top;
}CharStack;

CharStack* CreateCharStack(int max)
{
    CharStack *S = (CharStack*) calloc(1,sizeof(CharStack));
    S->max = max;
    S->top = -1;
    S->charStackArr = (char*) calloc (max,sizeof(char));
}

int Is_CharStackEmpty(CharStack S)
{
    if(S.top < 0)  // top == -1
        return 1;
    return 0;
}

int Is_CharStackFull(CharStack S)
{
    if(S.top >= S.max-1)  // top == MAX
        return 1;
    return 0;
}

void Push_CharStack(CharStack *S, char ch)
{
    if(Is_CharStackFull(*S)){
        printf("CHARSTACK OVERFLOW - PUSH OPERATION FAILED\n");
        return;
    }
    S->top++;
    S->charStackArr[S->top] = ch;
}

char Pop_CharStack(CharStack *S)
{
    if(Is_CharStackEmpty(*S)){
        printf("CHARSTACK UNDERFLOW - POP OPERATION FAILED\n");
        return '\0';
    }
    char temp = S->charStackArr[S->top];
    S->top--;
    return temp;
}

char Peak_CharStack(CharStack S)
{
    if(Is_CharStackEmpty(S)){
        printf("CHARSTACK UNDERFLOW - PEAK OPERATION FAILED\n");
        return '\0';
    }
    char temp = S.charStackArr[S.top];
    return temp;
}

void Display_CharStack(CharStack S)
{
    if(Is_CharStackEmpty(S)){
        printf("CHARSTACK UNDERFLOW - DISPLAY OPERATION FAILED\n");
        return;
    }
    // printf("TOP = %d",S.top);
    for(int i = S.top; i>=0 ;i--)
    {
        printf("| %c |\n",S.charStackArr[i]);
        printf("|---|\n");
    }
    printf("|***|\n");
}

CharStack* DestroyCharStack(CharStack *S)
{
    free(S->charStackArr);
    free(S);
    S = NULL;
}