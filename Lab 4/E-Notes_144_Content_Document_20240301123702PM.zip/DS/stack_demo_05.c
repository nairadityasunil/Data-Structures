#include "stack_char.c"
int main()
{
    char n;
    int ch;
    CharStack *S = NULL;
    do
    {
        printf("\n\nStack Menu\n0. Create\n1. Push \n2. Pop\n3. Display\n4. Peak\n5. Destroy\n9. Exit");
        printf("\nEnter Choice : ");
        scanf("%d", &ch);
        switch (ch)
        {
            case 0:
                printf("\nEnter Max Size: ");
                int sz;
                scanf("%d",&sz);
                S = CreateCharStack(sz);
                break;
            case 1:
                if(S==NULL){
                    printf("Stack not Created - Select Create Option \n");
                    break;   
                }
                printf("\nEnter Char to Push:  ");
                scanf(" %c", &n);
                Push_CharStack(S,n);
                break;
            case 2:
                if(S==NULL){
                    printf("Stack not Created - Select Create Option \n");
                    break;   
                }
                char t = Pop_CharStack(S);
                if(t == '\0');
                printf("Pop in Stack we got: %c \n",t);
                break;
            case 3:
                if(S==NULL){
                    printf("Stack not Created - Select Create Option \n");
                    break;   
                }
                Display_CharStack(*S);
                break;
            case 4:
                if(S==NULL){
                    printf("Stack not Created - Select Create Option \n");
                    break;   
                }
                printf("Peak in Stack is: %c \n",Peak_CharStack(*S));
                break;
            case 5:
                if(S==NULL){
                    printf("Stack not Created - Select Create Option \n");
                    break;   
                }
                printf("Stack is been Removed \n");
                DestroyCharStack(S);
                break;
        }
    }while (ch != 9);
}